﻿using System;
using Microsoft.EntityFrameworkCore;
using NEGOSUD.Common.Models;
using NEGOSUD.DataAccess;

namespace NEGOSUD.Services.RoleService
{
    public class RoleService : IRoleService
    {
        private readonly DataContext _context;

        public RoleService(DataContext context)
        {
            _context = context;
        }
        public async Task<List<Role>> AddRole(Role role)
        {
            _context.Roles.Add(role);
            await _context.SaveChangesAsync();

            return await _context.Roles.ToListAsync();
        }

        public async Task<List<Role>?> DeleteRole(int id)
        {
            var role = await _context.Roles.FindAsync(id);
            if (role is null)
                return null;

            _context.Roles.Remove(role);
            await _context.SaveChangesAsync();

            return await _context.Roles.ToListAsync();
        }

        public async Task<List<Role>> GetAllRoles()
        {
            var roles = await _context.Roles.ToListAsync();
            return roles;
        }

        public async Task<Role?> GetOneRole(int id)
        {
            var role = await _context.Roles.FindAsync(id);
            if (role is null)
                return null;

            return role;
        }

        public async Task<List<Role>?> UpdateRole(Role request)
        {
            var role = await _context.Roles.FindAsync(request.Id);
            if (role is null)
                return null;

            if (request.Name != string.Empty)
                role.Name = request.Name;

            await _context.SaveChangesAsync();

            return await _context.Roles.ToListAsync();
        }
    }
}

