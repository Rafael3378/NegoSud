﻿using System;
using Microsoft.EntityFrameworkCore;
using NEGOSUD.Common.Models;
using NEGOSUD.DataAccess;

namespace NEGOSUD.Services.StatusService
{
	public class StatusService : IStatusService
	{
        private readonly DataContext _context;

        public StatusService(DataContext context)
		{
            _context = context;
        }

        public async Task<List<Status>> AddStatus(Status status)
        {
            _context.Status.Add(status);
            await _context.SaveChangesAsync();

            return await _context.Status.ToListAsync();
        }

        public async Task<List<Status>?> DeleteStatus(int id)
        {
            var status = await _context.Status.FindAsync(id);
            if (status is null)
                return null;

            _context.Status.Remove(status);
            await _context.SaveChangesAsync();

            return await _context.Status.ToListAsync();
        }

        public async Task<List<Status>> GetAllStatus()
        {
            var status = await _context.Status.ToListAsync();
            return status;
        }

        public async Task<Status?> GetOneStatus(int id)
        {
            var status = await _context.Status.FindAsync(id);
            if (status is null)
                return null;

            return status;
        }

        public async Task<List<Status>?> UpdateStatus(Status request)
        {
            var status = await _context.Status.FindAsync(request.Id);
            if (status is null)
                return null;

            if (request.Name != string.Empty)
                status.Name = request.Name;

            await _context.SaveChangesAsync();

            return await _context.Status.ToListAsync();
        }
    }
}

