﻿using System;
using NEGOSUD.Common.Models;

namespace NEGOSUD.Services.StatusService
{
	public interface IStatusService
	{
        Task<List<Status>> GetAllStatus();

        Task<Status?> GetOneStatus(int id);

        Task<List<Status>> AddStatus(Status status);

        Task<List<Status>?> UpdateStatus(Status request);

        Task<List<Status>?> DeleteStatus(int id);
    }
}

