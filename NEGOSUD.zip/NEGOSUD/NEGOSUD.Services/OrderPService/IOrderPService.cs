﻿using System;
using NEGOSUD.Common.Models;

namespace NEGOSUD.Services.OrderPService
{
	public interface IOrderPService
	{
        Task<List<OrderP>> GetAllOrdersP();

        Task<OrderP?> GetOneOrderP(int id);

        Task<List<OrderP>> AddOrderP(OrderP orderP);

        Task<List<OrderP>?> UpdateOrderP(OrderP request);

        Task<List<OrderP>?> DeleteOrderP(int id);
    }
}

