﻿using System;
using Microsoft.EntityFrameworkCore;
using NEGOSUD.Common.Models;
using NEGOSUD.DataAccess;

namespace NEGOSUD.Services.ItemService
{
	public class ItemService : IItemService
	{
        private readonly DataContext _context;

        public ItemService(DataContext context)
		{
            _context = context;
        }

        public async Task<List<Item>> AddItem(Item item)
        {
            _context.Items.Add(item);
            await _context.SaveChangesAsync();

            return await _context.Items.ToListAsync();
        }

        public async Task<List<Item>?> DeleteItem(int id)
        {
            var item = await _context.Items.FindAsync(id);
            if (item is null)
                return null;

            _context.Items.Remove(item);
            await _context.SaveChangesAsync();

            return await _context.Items.ToListAsync();
        }

        public async Task<List<Item>> GetAllItems()
        {
            var items = await _context.Items.ToListAsync();
            return items;
        }

        public async Task<Item?> GetOneItem(int id)
        {
            var item = await _context.Items.FindAsync(id);
            if (item is null)
                return null;

            return item;
        }

        public async Task<List<Item>?> UpdateItem(int id, Item request)
        {
            var item = await _context.Items.FindAsync(request.Id);

            if (item is null)
                return null;

            if (request.Name != string.Empty)
                item.Name = request.Name;
            if (request.Appellation != string.Empty)
                item.Appellation = request.Appellation;
            if (request.Volume != int.MinValue)
                item.Volume = request.Volume;
            if (request.Year != int.MinValue)
                item.Year = request.Year;
            if (request.UnitPrice != int.MinValue)
                item.UnitPrice = request.UnitPrice;
            if (request.BoxPrice != int.MinValue)
                item.BoxPrice = request.BoxPrice;
            if (request.Region != string.Empty)
                item.Region = request.Region;
            if (request.Image != string.Empty)
                item.Image = request.Image;
            if (request.WineTypeId != int.MinValue)
                item.WineTypeId = request.WineTypeId;
            if (request.ProviderId != int.MinValue)
                item.ProviderId = request.ProviderId;

            await _context.SaveChangesAsync();

            return await _context.Items.ToListAsync();
        }
    }
}

