﻿using System;
using Microsoft.EntityFrameworkCore;
using NEGOSUD.Common.Models;
using NEGOSUD.DataAccess;

namespace NEGOSUD.Services.WineTypeService
{
	public class WineTypeService : IWineTypeService
	{
        private readonly DataContext _context;

        public WineTypeService(DataContext context)
		{
            _context = context;
        }

        public async Task<List<WineType>> AddWineType(WineType wineType)
        {
            _context.WineTypes.Add(wineType);
            await _context.SaveChangesAsync();

            return await _context.WineTypes.ToListAsync();
        }

        public async Task<List<WineType>?> DeleteWineType(int id)
        {
            var wineType = await _context.WineTypes.FindAsync(id);
            if (wineType is null)
                return null;

            _context.WineTypes.Remove(wineType);
            await _context.SaveChangesAsync();

            return await _context.WineTypes.ToListAsync();
        }

        public async Task<List<WineType>> GetAllWineTypes()
        {
            var wineTypes = await _context.WineTypes.ToListAsync();
            return wineTypes;
        }

        public async Task<WineType?> GetOneWineType(int id)
        {
            var wineType = await _context.WineTypes.FindAsync(id);
            if (wineType is null)
                return null;

            return wineType;
        }

        public async Task<List<WineType>?> UpdateWineType(int id, WineType request)
        {
            var wineType = await _context.WineTypes.FindAsync(request.Id);
            if (wineType is null)
                return null;

            if (request.Color != string.Empty)
                wineType.Color = request.Color;

            await _context.SaveChangesAsync();

            return await _context.WineTypes.ToListAsync();
        }
    }
}

