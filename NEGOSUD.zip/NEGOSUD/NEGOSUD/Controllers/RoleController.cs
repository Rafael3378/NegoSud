﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using NEGOSUD.Common.Models;
using NEGOSUD.Services.RoleService;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace NEGOSUD.Controllers
{
    [Route("api/[controller]")]
    public class RoleController : ControllerBase
    {
        private readonly IRoleService _roleService;

        public RoleController(IRoleService roleService)
        {
            _roleService = roleService;
        }

        // GET: api/values
        [HttpGet]
        public async Task<ActionResult<List<Role>>> GetAllRoles()
        {
            return await _roleService.GetAllRoles();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Role>> GetOneRole(int id)
        {
            var result = await _roleService.GetOneRole(id);
            if (result is null)
                return NotFound("Role not found.");

            return Ok(result);
        }

        [HttpPost]
        public async Task<ActionResult<List<Role>>> AddRole(Role role)
        {
            var result = await _roleService.AddRole(role);
            return Ok(result);
        }

        [HttpPut]
        public async Task<ActionResult<List<Role>>> UpdateRole(Role request)
        {
            var result = await _roleService.UpdateRole(request);
            if (result is null)
                return NotFound("Role not found.");

            return Ok(result);
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult<List<Role>>> DeleteRole(int id)
        {
            var result = await _roleService.DeleteRole(id);
            if (result is null)
                return NotFound("Role not found.");

            return Ok(result);
        }
    }
}

