﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using NEGOSUD.Common.Models;
using NEGOSUD.Services.ProviderService;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace NEGOSUD.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProviderController : ControllerBase
    {
        private readonly IProviderService _providerService;

        public ProviderController(IProviderService providerService)
        {
            _providerService = providerService;
        }

        // GET: api/values
        [HttpGet]
        public async Task<ActionResult<List<Provider>>> GetAllProviders()
        {
            return await _providerService.GetAllProviders();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Provider>> GetOneProvider(int id)
        {
            var result = await _providerService.GetOneProvider(id);
            if (result is null)
                return NotFound("Provider not found.");

            return Ok(result);
        }

        [HttpPost]
        public async Task<ActionResult<List<Provider>>> AddProvider(Provider provider)
        {
            var result = await _providerService.AddProvider(provider);
            return Ok(result);
        }

        [HttpPut]
        public async Task<ActionResult<List<Provider>>> UpdateProvider(int id, Provider request)
        {
            var result = await _providerService.UpdateProvider(id, request);
            if (result is null)
                return NotFound("Provider not found.");

            return Ok(result);
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult<List<Provider>>> DeleteProvider(int id)
        {
            var result = await _providerService.DeleteProvider(id);
            if (result is null)
                return NotFound("Provider not found.");

            return Ok(result);
        }
    }
}

