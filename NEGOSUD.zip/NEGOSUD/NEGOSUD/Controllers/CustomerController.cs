﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using NEGOSUD.Common.Models;
using NEGOSUD.Services.CustomerService;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace NEGOSUD.Controllers
{
    [Route("api/[controller]")]
    public class CustomerController : ControllerBase
    {
        private readonly ICustomerService _customerService;

        public CustomerController(ICustomerService customerService)
        {
            _customerService = customerService;
        }

        // GET: api/values
        [HttpGet]
        public async Task<ActionResult<List<Customer>>> GetAllCustomers()
        {
            return await _customerService.GetAllCustomers();
        }

        [HttpGet("{id}", Name = "Afficher un utilisateur" )]
        public async Task<ActionResult<Customer>> GetOneCustomer(int id)
        {
            var result = await _customerService.GetOneCustomer(id);
            if (result is null)
                return NotFound("Customer not found.");

            return Ok(result);
        }

        [HttpPost]
        public async Task<ActionResult<List<Customer>>> AddCustomer(Customer customer)
        {
            var result = await _customerService.AddCustomer(customer);
            return Ok(result);
        }

        [HttpPut]
        public async Task<ActionResult<List<Customer>>> UpdateCustomer(Customer request)
        {
            var result = await _customerService.UpdateCustomer(request);
            if (result is null)
                return NotFound("Customer not found.");

            return Ok(result);
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult<List<Customer>>> DeleteCustomer(int id)
        {
            var result = await _customerService.DeleteCustomer(id);
            if (result is null)
                return NotFound("Customer not found.");

            return Ok(result);
        }
    }
}

