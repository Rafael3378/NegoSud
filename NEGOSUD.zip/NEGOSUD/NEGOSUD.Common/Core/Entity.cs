﻿using System;
using System.ComponentModel.DataAnnotations;

namespace NEGOSUD.Common.Core
{
	public class Entity
	{
        [Key]
        public int Id { get; set; }

		public Entity()
		{
		}
	}
}

