﻿using System;
using NEGOSUD.Common.Core;

namespace NEGOSUD.Common.Models
{
	public class Status : Entity
	{
		public string Name { get; set; } = string.Empty;

		public virtual List<OrderC> OrdersC { get; set; }

        public virtual List<OrderP> OrdersP { get; set; }

        public Status()
		{
		}
	}
}

