﻿using System;
using System.ComponentModel.DataAnnotations.Schema;
using NEGOSUD.Common.Core;

namespace NEGOSUD.Common.Models
{
	public class Employee : Entity
	{
		public string Name { get; set; } = string.Empty;

        public string LastName { get; set; } = string.Empty;

        public string Email { get; set; } = string.Empty;

        public string Password { get; set; } = string.Empty;

        [ForeignKey("RoleId")]
        public int RoleId { get; set; }

        public Employee()
		{
		}
	}
}

