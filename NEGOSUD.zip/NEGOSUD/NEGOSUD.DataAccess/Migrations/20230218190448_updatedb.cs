﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace NEGOSUD.DataAccess.Migrations
{
    /// <inheritdoc />
    public partial class updatedb : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_WineTypes",
                table: "WineTypes");

            migrationBuilder.DropIndex(
                name: "IX_WineTypes_Name",
                table: "WineTypes");

            migrationBuilder.DropColumn(
                name: "ProviderName",
                table: "Items");

            migrationBuilder.DropColumn(
                name: "WineTypeName",
                table: "Items");

            migrationBuilder.AlterColumn<string>(
                name: "Name",
                table: "WineTypes",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(450)");

            migrationBuilder.AddColumn<int>(
                name: "ProviderId",
                table: "Items",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "WineTypeId",
                table: "Items",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddPrimaryKey(
                name: "PK_WineTypes",
                table: "WineTypes",
                column: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_WineTypes",
                table: "WineTypes");

            migrationBuilder.DropColumn(
                name: "ProviderId",
                table: "Items");

            migrationBuilder.DropColumn(
                name: "WineTypeId",
                table: "Items");

            migrationBuilder.AlterColumn<string>(
                name: "Name",
                table: "WineTypes",
                type: "nvarchar(450)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AddColumn<string>(
                name: "ProviderName",
                table: "Items",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "WineTypeName",
                table: "Items",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddPrimaryKey(
                name: "PK_WineTypes",
                table: "WineTypes",
                column: "Name");

            migrationBuilder.CreateIndex(
                name: "IX_WineTypes_Name",
                table: "WineTypes",
                column: "Name",
                unique: true);
        }
    }
}
