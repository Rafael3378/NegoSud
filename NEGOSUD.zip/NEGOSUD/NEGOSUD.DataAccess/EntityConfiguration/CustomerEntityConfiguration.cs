﻿using System;
using Microsoft.EntityFrameworkCore;
using NEGOSUD.Common.Models;

namespace NEGOSUD.DataAccess.EntityConfiguration
{
	public class CustomerEntityConfiguration : IEntityTypeConfiguration<Customer>
	{
		public CustomerEntityConfiguration()
		{
		}

        public void Configure(Microsoft.EntityFrameworkCore.Metadata.Builders.EntityTypeBuilder<Customer> customer)
        {
            customer.HasKey(c => c.Id);
            customer.Property(c => c.Id).ValueGeneratedOnAdd();

            customer.Property<string>("Name").IsRequired();
            customer.Property<string>("LastName").IsRequired();
            customer.Property<string>("Email").IsRequired();

            customer.HasIndex(c => c.Email).IsUnique();
        }
    }
}

