﻿using System;
using System.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using NEGOSUD.Common.Models;

namespace NEGOSUD.DataAccess.EntityConfiguration
{
	public class RoleEntityConfiguration : IEntityTypeConfiguration<Role>
    {
		public RoleEntityConfiguration()
		{
		}

        public void Configure(EntityTypeBuilder<Role> role)
        {
            role.HasKey(r => r.Id);
            role.Property(r => r.Id).ValueGeneratedOnAdd();

            role.Property<string>("Name").IsRequired();

            role.HasIndex(r => r.Name).IsUnique();

        }
    }
}

