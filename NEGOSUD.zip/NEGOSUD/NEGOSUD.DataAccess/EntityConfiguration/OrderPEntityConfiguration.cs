﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using NEGOSUD.Common.Models;

namespace NEGOSUD.DataAccess.EntityConfiguration
{
	public class OrderPEntityConfiguration : IEntityTypeConfiguration<OrderP>
    {
		public OrderPEntityConfiguration()
		{
		}

        public void Configure(EntityTypeBuilder<OrderP> orderp)
        {
            orderp.HasKey(op => op.Id);
            orderp.Property(op => op.Id).ValueGeneratedOnAdd();

            orderp.Property<string>("OrderNumber").IsRequired();
            orderp.Property<DateTime>("OrderDate").IsRequired();
            orderp.Property<int>("Quantity").IsRequired();
            orderp.Property<float>("Price").IsRequired();

            orderp.HasIndex(op => op.OrderNumber).IsUnique();
        }
    }
}

